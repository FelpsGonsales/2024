/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Gonsales
 */
@Entity
@Table(name = "pedido_has_criptomoeda")
@NamedQueries({
    @NamedQuery(name = "PedidoHasCriptomoeda.findAll", query = "SELECT p FROM PedidoHasCriptomoeda p")})
public class PedidoHasCriptomoeda implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PedidoHasCriptomoedaPK pedidoHasCriptomoedaPK;
    @Basic(optional = false)
    @Column(name = "quantidade_pedido")
    private double quantidadePedido;
    @Basic(optional = false)
    @Column(name = "valor_pago")
    private String valorPago;
    @JoinColumn(name = "Criptomoeda_idCriptomoeda", referencedColumnName = "idCriptomoeda", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Criptomoeda criptomoeda;
    @JoinColumn(name = "Pedido_idPedido", referencedColumnName = "idPedido", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Pedido pedido;

    public PedidoHasCriptomoeda() {
    }

    public PedidoHasCriptomoeda(PedidoHasCriptomoedaPK pedidoHasCriptomoedaPK) {
        this.pedidoHasCriptomoedaPK = pedidoHasCriptomoedaPK;
    }

    public PedidoHasCriptomoeda(PedidoHasCriptomoedaPK pedidoHasCriptomoedaPK, double quantidadePedido, String valorPago) {
        this.pedidoHasCriptomoedaPK = pedidoHasCriptomoedaPK;
        this.quantidadePedido = quantidadePedido;
        this.valorPago = valorPago;
    }

    public PedidoHasCriptomoeda(int pedidoidPedido, int criptomoedaidCriptomoeda) {
        this.pedidoHasCriptomoedaPK = new PedidoHasCriptomoedaPK(pedidoidPedido, criptomoedaidCriptomoeda);
    }

    public PedidoHasCriptomoedaPK getPedidoHasCriptomoedaPK() {
        return pedidoHasCriptomoedaPK;
    }

    public void setPedidoHasCriptomoedaPK(PedidoHasCriptomoedaPK pedidoHasCriptomoedaPK) {
        this.pedidoHasCriptomoedaPK = pedidoHasCriptomoedaPK;
    }

    public double getQuantidadePedido() {
        return quantidadePedido;
    }

    public void setQuantidadePedido(double quantidadePedido) {
        this.quantidadePedido = quantidadePedido;
    }

    public String getValorPago() {
        return valorPago;
    }

    public void setValorPago(String valorPago) {
        this.valorPago = valorPago;
    }

    public Criptomoeda getCriptomoeda() {
        return criptomoeda;
    }

    public void setCriptomoeda(Criptomoeda criptomoeda) {
        this.criptomoeda = criptomoeda;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pedidoHasCriptomoedaPK != null ? pedidoHasCriptomoedaPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PedidoHasCriptomoeda)) {
            return false;
        }
        PedidoHasCriptomoeda other = (PedidoHasCriptomoeda) object;
        if ((this.pedidoHasCriptomoedaPK == null && other.pedidoHasCriptomoedaPK != null) || (this.pedidoHasCriptomoedaPK != null && !this.pedidoHasCriptomoedaPK.equals(other.pedidoHasCriptomoedaPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.PedidoHasCriptomoeda[ pedidoHasCriptomoedaPK=" + pedidoHasCriptomoedaPK + " ]";
    }
    
}
