/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Gonsales
 */
@Entity
@Table(name = "criptomoeda")
@NamedQueries({
    @NamedQuery(name = "Criptomoeda.findAll", query = "SELECT c FROM Criptomoeda c")})
public class Criptomoeda implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idCriptomoeda")
    private Integer idCriptomoeda;
    @Basic(optional = false)
    @Column(name = "nome_criptomoeda")
    private String nomeCriptomoeda;
    @Basic(optional = false)
    @Column(name = "nome_criador")
    private String nomeCriador;
    @Basic(optional = false)
    @Column(name = "sigla_criptomoeda")
    private String siglaCriptomoeda;
    @Column(name = "quantidade_estoque")
    private String quantidadeEstoque;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "criptomoeda")
    private List<PedidoHasCriptomoeda> pedidoHasCriptomoedaList;

    public Criptomoeda() {
    }

    public Criptomoeda(Integer idCriptomoeda) {
        this.idCriptomoeda = idCriptomoeda;
    }

    public Criptomoeda(Integer idCriptomoeda, String nomeCriptomoeda, String nomeCriador, String siglaCriptomoeda) {
        this.idCriptomoeda = idCriptomoeda;
        this.nomeCriptomoeda = nomeCriptomoeda;
        this.nomeCriador = nomeCriador;
        this.siglaCriptomoeda = siglaCriptomoeda;
    }

    public Integer getIdCriptomoeda() {
        return idCriptomoeda;
    }

    public void setIdCriptomoeda(Integer idCriptomoeda) {
        this.idCriptomoeda = idCriptomoeda;
    }

    public String getNomeCriptomoeda() {
        return nomeCriptomoeda;
    }

    public void setNomeCriptomoeda(String nomeCriptomoeda) {
        this.nomeCriptomoeda = nomeCriptomoeda;
    }

    public String getNomeCriador() {
        return nomeCriador;
    }

    public void setNomeCriador(String nomeCriador) {
        this.nomeCriador = nomeCriador;
    }

    public String getSiglaCriptomoeda() {
        return siglaCriptomoeda;
    }

    public void setSiglaCriptomoeda(String siglaCriptomoeda) {
        this.siglaCriptomoeda = siglaCriptomoeda;
    }

    public String getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    public void setQuantidadeEstoque(String quantidadeEstoque) {
        this.quantidadeEstoque = quantidadeEstoque;
    }

    public List<PedidoHasCriptomoeda> getPedidoHasCriptomoedaList() {
        return pedidoHasCriptomoedaList;
    }

    public void setPedidoHasCriptomoedaList(List<PedidoHasCriptomoeda> pedidoHasCriptomoedaList) {
        this.pedidoHasCriptomoedaList = pedidoHasCriptomoedaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCriptomoeda != null ? idCriptomoeda.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Criptomoeda)) {
            return false;
        }
        Criptomoeda other = (Criptomoeda) object;
        if ((this.idCriptomoeda == null && other.idCriptomoeda != null) || (this.idCriptomoeda != null && !this.idCriptomoeda.equals(other.idCriptomoeda))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.Criptomoeda[ idCriptomoeda=" + idCriptomoeda + " ]";
    }
    
}
