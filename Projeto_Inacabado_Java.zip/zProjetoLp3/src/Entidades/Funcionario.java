/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import myUtil.ConversorDeDatas;

/**
 *
 * @author Gonsales
 */
@Entity
@Table(name = "funcionario")
@NamedQueries({
    @NamedQuery(name = "Funcionario.findAll", query = "SELECT f FROM Funcionario f")})
public class Funcionario implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "Pessoa_idPessoa")
    private Integer pessoaidPessoa;
    @Basic(optional = false)
    @Column(name = "data_contrato")
    @Temporal(TemporalType.DATE)
    private Date dataContrato;
    @JoinColumn(name = "Departamento_idDepartamento", referencedColumnName = "idDepartamento")
    @ManyToOne(optional = false)
    private Departamento departamentoidDepartamento;
    @JoinColumn(name = "Pessoa_idPessoa", referencedColumnName = "idPessoa", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Pessoa pessoa;

    public Funcionario() {
    }

    public Funcionario(Integer pessoaidPessoa) {
        this.pessoaidPessoa = pessoaidPessoa;
    }

    public Funcionario(Integer pessoaidPessoa, Date dataContrato) {
        this.pessoaidPessoa = pessoaidPessoa;
        this.dataContrato = dataContrato;
    }

    public Integer getPessoaidPessoa() {
        return pessoaidPessoa;
    }

    public void setPessoaidPessoa(Integer pessoaidPessoa) {
        this.pessoaidPessoa = pessoaidPessoa;
    }

    public Date getDataContrato() {
        return dataContrato;
    }

    public void setDataContrato(Date dataContrato) {
        this.dataContrato = dataContrato;
    }

    public Departamento getDepartamentoidDepartamento() {
        return departamentoidDepartamento;
    }

    public void setDepartamentoidDepartamento(Departamento departamentoidDepartamento) {
        this.departamentoidDepartamento = departamentoidDepartamento;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pessoaidPessoa != null ? pessoaidPessoa.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Funcionario)) {
            return false;
        }
        Funcionario other = (Funcionario) object;
        if ((this.pessoaidPessoa == null && other.pessoaidPessoa != null) || (this.pessoaidPessoa != null && !this.pessoaidPessoa.equals(other.pessoaidPessoa))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        ConversorDeDatas cd = new ConversorDeDatas();
        return pessoaidPessoa + ";" + cd.getDateParaStringBr(dataContrato)+ ";" + departamentoidDepartamento.getNomeDep();
    }
    
}
