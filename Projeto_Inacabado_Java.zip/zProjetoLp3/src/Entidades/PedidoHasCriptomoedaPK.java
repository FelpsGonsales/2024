/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author Gonsales
 */
@Embeddable
public class PedidoHasCriptomoedaPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "Pedido_idPedido")
    private int pedidoidPedido;
    @Basic(optional = false)
    @Column(name = "Criptomoeda_idCriptomoeda")
    private int criptomoedaidCriptomoeda;

    public PedidoHasCriptomoedaPK() {
    }

    public PedidoHasCriptomoedaPK(int pedidoidPedido, int criptomoedaidCriptomoeda) {
        this.pedidoidPedido = pedidoidPedido;
        this.criptomoedaidCriptomoeda = criptomoedaidCriptomoeda;
    }

    public int getPedidoidPedido() {
        return pedidoidPedido;
    }

    public void setPedidoidPedido(int pedidoidPedido) {
        this.pedidoidPedido = pedidoidPedido;
    }

    public int getCriptomoedaidCriptomoeda() {
        return criptomoedaidCriptomoeda;
    }

    public void setCriptomoedaidCriptomoeda(int criptomoedaidCriptomoeda) {
        this.criptomoedaidCriptomoeda = criptomoedaidCriptomoeda;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) pedidoidPedido;
        hash += (int) criptomoedaidCriptomoeda;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PedidoHasCriptomoedaPK)) {
            return false;
        }
        PedidoHasCriptomoedaPK other = (PedidoHasCriptomoedaPK) object;
        if (this.pedidoidPedido != other.pedidoidPedido) {
            return false;
        }
        if (this.criptomoedaidCriptomoeda != other.criptomoedaidCriptomoeda) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.PedidoHasCriptomoedaPK[ pedidoidPedido=" + pedidoidPedido + ", criptomoedaidCriptomoeda=" + criptomoedaidCriptomoeda + " ]";
    }
    
}
