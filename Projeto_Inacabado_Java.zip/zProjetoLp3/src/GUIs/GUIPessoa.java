package GUIs;

import DAOs.DAOCliente;
import DAOs.DAOPessoa;
import Entidades.Cliente;
import Entidades.Pessoa;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import myUtil.DateTextField;
import myUtil.JanelaPesquisar;

public class GUIPessoa extends JDialog {

    Container cp;

    JPanel pnNorte = new JPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JLabel lbIdPessoa = new JLabel("Id da Pessoa");
    JTextField tfIdPessoa = new JTextField(20);

    JLabel lbNome = new JLabel("Nome");
    JTextField tfNome = new JTextField(50);

    JLabel lbDataN = new JLabel("Data de Nascimento");
    DateTextField tfDataN = new DateTextField();

    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btAddCliente = new JButton("Adicionar como Cliente");
    JButton btTiraCliente = new JButton("Remover como Cliente");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");

    DAOPessoa daoPessoa = new DAOPessoa();
    Pessoa pessoa = new Pessoa();
    String acao = "";

    String[] colunas = new String[]{"Id", "Pessoa", "Data de Nascimento"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));
    private CardLayout cardLayout;

    public GUIPessoa() {

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - Pessoa");

        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(Color.black);
        pnCentro.setBackground(Color.black);
        pnSul.setBackground(Color.black);
        pnSul.setBorder(BorderFactory.createLineBorder(Color.gray));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        pnNorte.add(lbIdPessoa);
        pnNorte.add(tfIdPessoa);
        pnNorte.add(btBuscar);
        pnNorte.add(btAddCliente);
        pnNorte.add(btTiraCliente);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);

        pnCentro.setLayout(new GridLayout(3, 6));
        pnCentro.add(lbNome);
        pnCentro.add(tfNome);
        pnCentro.add(lbDataN);
        pnCentro.add(tfDataN);

        tfNome.setBackground(Color.black);
        tfNome.setForeground(Color.green);

        lbNome.setForeground(Color.green);
        lbNome.setBackground(Color.black);

        lbIdPessoa.setBackground(Color.black);
        lbIdPessoa.setForeground(Color.green);

        tfDataN.setForeground(Color.green);
        tfDataN.setBackground(Color.black);

        lbDataN.setBackground(Color.black);
        lbDataN.setForeground(Color.green);

        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnVazio.setBackground(Color.black);
        pnSul.add(pnAvisos, " ");
        pnAvisos.setBackground(Color.black);
        pnAvisos.setForeground(Color.green);
        pnSul.add(pnListagem, "listagem");
        pnListagem.setBackground(Color.black);
        pnListagem.setForeground(Color.green);
        tabela.setEnabled(false);
        tabela.setBackground(Color.black);
        tabela.setForeground(Color.green);

        pnAvisos.add(new JLabel("Avisos"));

        tfNome.setEditable(false);

        tfIdPessoa.setBackground(Color.black);
        tfIdPessoa.setForeground(Color.green);
        btBuscar.setForeground(Color.green);
        btBuscar.setBackground(Color.black);
        btBuscar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                pessoa = new Pessoa();
                tfIdPessoa.setText(tfIdPessoa.getText().trim());//caso tenham sido digitados espaços

                if (tfIdPessoa.getText().equals("")) {
                    List<String> listaAuxiliar = daoPessoa.listInOrderNomeStrings("id");
                    if (listaAuxiliar.size() > 0) {
                        Point lc = btBuscar.getLocationOnScreen();
                        lc.x = lc.x + btBuscar.getWidth();
                        String selectedItem = new JanelaPesquisar(listaAuxiliar,
                                lc.x,
                                lc.y).getValorRetornado();
                        if (!selectedItem.equals("")) {
                            String[] aux = selectedItem.split("-");
                            tfIdPessoa.setText(aux[0]);
                            btBuscar.doClick();
                        } else {
                            tfIdPessoa.requestFocus();
                            tfIdPessoa.selectAll();
                        }
                    }

                    tfIdPessoa.requestFocus();
                    tfIdPessoa.selectAll();
                } else {
                    try {
                        pessoa.setIdPessoa(Integer.valueOf(tfIdPessoa.getText()));
                        pessoa = daoPessoa.obter(pessoa.getIdPessoa());
                        if (pessoa != null) { //se encontrou na lista
                            tfNome.setText(String.valueOf(pessoa.getNomePessoa()));
                           tfDataN.setText(String.valueOf(pessoa.getDataNascimentoPessoa()));

                            btAdicionar.setVisible(false);
                            btAlterar.setVisible(true);
                            btExcluir.setVisible(true);
                            btSalvar.setVisible(false);
                            btCancelar.setVisible(false);
                            btBuscar.setVisible(false);
                            btListar.setVisible(true);
                            acao = "encontrou";
                        } else {
                            btAdicionar.setVisible(true);
                            btSalvar.setVisible(false);
                            btCancelar.setVisible(false);
                            btBuscar.setVisible(true);
                            btListar.setVisible(true);
                        }
                        tfIdPessoa.setBackground(Color.black);
                        tfIdPessoa.setForeground(Color.green);
                    } catch (Exception x) {
                        tfIdPessoa.setOpaque(true);
                        tfIdPessoa.selectAll();
                        tfIdPessoa.requestFocus();
                        tfIdPessoa.setBackground(Color.red);

                    }
                }
            }
        });
        btAdicionar.setForeground(Color.green);
        btAdicionar.setBackground(Color.black);
        btAdicionar.addActionListener((ActionEvent e) -> {
            tfNome.requestFocus();
            tfIdPessoa.setEnabled(false);
            tfNome.setEditable(true);
            tfDataN.setEditable(true);
            tfDataN.setText("");

            btAdicionar.setVisible(false);
            btSalvar.setVisible(true);
            btCancelar.setVisible(true);
            btBuscar.setVisible(false);
            btListar.setVisible(false);
            acao = "Adicionar";
        });
        btSalvar.setForeground(Color.green);
        btSalvar.setBackground(Color.black);
        btSalvar.addActionListener((ActionEvent e) -> {
            if (acao.equals("Adicionar")) {
                pessoa = new Pessoa();
            }

            pessoa.setIdPessoa(Integer.valueOf(tfIdPessoa.getText()));
            pessoa.setNomePessoa(tfNome.getText());
            pessoa.setDataNascimentoPessoa(tfDataN.getDate());
            
            if (acao.equals("Adicionar")) {
                daoPessoa.inserir(pessoa);
            } else {
                daoPessoa.atualizar(pessoa);
            }
            btSalvar.setVisible(false);
            btCancelar.setVisible(false);
            tfIdPessoa.setEnabled(true);
            tfIdPessoa.setEditable(true);
            tfIdPessoa.requestFocus();

            tfIdPessoa.setText("");
            tfNome.setText("");
            tfDataN.setText("");
            
            btBuscar.setVisible(true);
            btListar.setVisible(true);
            
            tfNome.setEditable(false);
            tfDataN.setEditable(false);
        });
        btAlterar.setForeground(Color.green);
        btAlterar.setBackground(Color.black);
        btAlterar.addActionListener((ActionEvent e) -> {
            btBuscar.setVisible(false);
            btAlterar.setVisible(false);
            tfNome.requestFocus();
            tfIdPessoa.setEditable(false);
            tfNome.setEditable(true);
            tfDataN.setEditable(true);

            btSalvar.setVisible(true);
            btCancelar.setVisible(true);
            btListar.setVisible(false);
            btExcluir.setVisible(false);
            acao = "alterar";
        });
        btExcluir.setForeground(Color.green);
        btExcluir.setBackground(Color.black);
        btExcluir.addActionListener((ActionEvent e) -> {
            int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {
                daoPessoa.remover(pessoa);
                System.out.println(pessoa.toString());
            }
            btExcluir.setVisible(false);
            tfIdPessoa.setEnabled(true);
            tfIdPessoa.setEditable(true);
            tfIdPessoa.requestFocus();
            tfIdPessoa.setText("");
            tfNome.setText("");
            tfDataN.setText("");

            btBuscar.setVisible(true);

            tfNome.setEditable(false);

            btAlterar.setVisible(false);
            btAdicionar.setVisible(false);
            btSalvar.setVisible(false);
            btCancelar.setVisible(false);
            btBuscar.setVisible(true);
            btListar.setVisible(true);
        });
        btListar.setForeground(Color.green);
        btListar.setBackground(Color.black);
        btListar.addActionListener((ActionEvent e) -> {
            List<Pessoa> listaPessoa = daoPessoa.listInOrderNome();
            String[] colunas1 = {"Id", "Nome da Pessoa", "Idade da Pessoa"};
            Object[][] dados1 = new Object[listaPessoa.size()][colunas1.length];
            String aux[];
            for (int i = 0; i < listaPessoa.size(); i++) {
                aux = listaPessoa.get(i).toString().split(";");
                for (int j = 0; j < colunas1.length; j++) {
                    try {
                        dados1[i][j] = aux[j];
                    } catch (Exception x1) {
                    }
                }
            }
            cardLayout.show(pnSul, "listagem");
            scrollTabela.setPreferredSize(tabela.getPreferredSize());
            pnListagem.add(scrollTabela);
            scrollTabela.setViewportView(tabela);
            model.setDataVector(dados1, colunas1);
            btAlterar.setVisible(false);
            btExcluir.setVisible(false);
            btBuscar.setVisible(true);
            btAdicionar.setVisible(false);
        });
        
        btAddCliente.setForeground(Color.green);
        btAddCliente.setBackground(Color.black);
        btAddCliente.addActionListener((ActionEvent e) -> {
          
            DAOCliente daoCliente = new DAOCliente();
            if (pessoa!= null) {
               Cliente c = daoCliente.obter(pessoa.getIdPessoa());
                if(c == null){
                    c = new Cliente();
                    c.setPessoaidPessoa(pessoa.getIdPessoa());
                    daoCliente.inserir(c);
                }
            }
        });
        
        btTiraCliente.setForeground(Color.green);
        btTiraCliente.setBackground(Color.black);
        btTiraCliente.addActionListener((ActionEvent e) -> {
          
            DAOCliente daoCliente = new DAOCliente();
            if (pessoa!= null) {
               Cliente c = daoCliente.obter(pessoa.getIdPessoa());
                if(c!= null){
                    daoCliente.remover(c);
                }
            }
        });
        
        btCancelar.setForeground(Color.green);
        btCancelar.setBackground(Color.black);
        btCancelar.addActionListener((ActionEvent e) -> {
            btCancelar.setVisible(false);
            tfIdPessoa.setText("");
            tfIdPessoa.requestFocus();
            tfIdPessoa.setEnabled(true);
            tfIdPessoa.setEditable(true);
            tfNome.setText("");

            tfDataN.setText("");

            tfDataN.setEditable(false);
            tfNome.setEditable(false);

            btBuscar.setVisible(true);
            btListar.setVisible(true);
            btSalvar.setVisible(false);
            btCancelar.setVisible(false);
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {

                dispose();
            }
        });

        setModal(true);
        setSize(1000, 400);
        setLocationRelativeTo(null);
        setVisible(true);

    }

    public static void main(String[] args) {
        GUIPessoa guiPessoa = new GUIPessoa();
    }

}
