package GUIs;

import DAOs.DAODepartamento;
import DAOs.DAOFuncionario;
import DAOs.DAOPessoa;
import Entidades.Departamento;
import Entidades.Funcionario;
import Entidades.Pessoa;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import myUtil.ConversorDeDatas;
import myUtil.DateTextField;
import myUtil.JanelaPesquisar;

public class GUIFuncionario extends JDialog {

    Container cp;

    JPanel pnNorte = new JPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JComboBox PessoaId = new JComboBox();
    JComboBox DepartamentoId = new JComboBox();
    
    JLabel lbIdPessoa = new JLabel("Id da Pessoa");
    JTextField tfIdPessoa = new JTextField(20);

    JLabel lbDataC = new JLabel("Data de Contrato");
    DateTextField tfDataC = new DateTextField();

    JLabel lbIdDepar = new JLabel("Id do Departamento");
    JTextField tfIdDepar = new JTextField(2);

    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");

    DAOFuncionario daoFuncionario = new DAOFuncionario();
    Funcionario funcionario = new Funcionario();
    
    String acao = "";
    

    String[] colunas = new String[]{"Id", "Data de Contrato", "Departamento"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));
    private final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private CardLayout cardLayout;

    public GUIFuncionario() {

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - Funcionario");

        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);

        pnNorte.setBackground(Color.black);
        pnCentro.setBackground(Color.black);
        pnSul.setBackground(Color.black);
        pnSul.setBorder(BorderFactory.createLineBorder(Color.gray));

        DAOPessoa daoPessoa = new DAOPessoa();
        String[] listaPessoa = daoPessoa.listInOrderNomeStringsArray();
        for (String s : listaPessoa) {
            PessoaId.addItem(s);
        }
        
        DAODepartamento daoDep = new DAODepartamento();
        String[] listaDep = daoDep.listInOrderNomeStringsArray();
        for (String s : listaDep) {
            DepartamentoId.addItem(s);
        }
        
        pnNorte.setLayout(new FlowLayout(FlowLayout.CENTER));
        pnNorte.add(PessoaId);
        pnNorte.add(lbIdPessoa);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);
        
        pnCentro.add(lbDataC);
        pnCentro.add(tfDataC);
        
        pnCentro.add(lbIdDepar);
        pnCentro.add(DepartamentoId);

        tfDataC.setBackground(Color.black);
        tfDataC.setForeground(Color.green);

        lbDataC.setForeground(Color.green);
        lbDataC.setBackground(Color.black);

        PessoaId.setForeground(Color.green);
        PessoaId.setBackground(Color.black);
        
        lbIdPessoa.setBackground(Color.black);
        lbIdPessoa.setForeground(Color.green);

        tfIdDepar.setForeground(Color.green);
        tfIdDepar.setBackground(Color.black);

        lbIdDepar.setBackground(Color.black);
        lbIdDepar.setForeground(Color.green);

        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnVazio.setBackground(Color.black);
        pnSul.add(pnAvisos, " ");
        pnAvisos.setBackground(Color.black);
        pnAvisos.setForeground(Color.green);
        pnSul.add(pnListagem, "listagem");
        pnListagem.setBackground(Color.black);
        pnListagem.setForeground(Color.green);
        tabela.setEnabled(false);
        tabela.setBackground(Color.black);
        tabela.setForeground(Color.green);

        pnAvisos.add(new JLabel("Avisos"));

        tfDataC.setEditable(false);

        tfIdPessoa.setBackground(Color.black);
        tfIdPessoa.setForeground(Color.green);
        
        btBuscar.setForeground(Color.green);
        btBuscar.setBackground(Color.black);
        
        ConversorDeDatas cd = new ConversorDeDatas();
        
        btBuscar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                funcionario = new Funcionario();
                tfIdPessoa.setText(tfIdPessoa.getText().trim());//caso tenham sido digitados espaços

                    String[] aux = listaPessoa[PessoaId.getSelectedIndex()].split("-");
                    tfIdPessoa.setText(aux[0]);
                    
                    String[] aux2 = listaDep[DepartamentoId.getSelectedIndex()].split("-");
                    tfIdDepar.setText(aux2[0]);
                
                if (tfIdPessoa.getText().equals("")) {
                    List<String> listaAuxiliar = daoFuncionario.listInOrderNomeStrings("id");
                    if (listaAuxiliar.size() > 0) {
                        Point lc = btBuscar.getLocationOnScreen();
                        lc.x = lc.x + btBuscar.getWidth();
                        String selectedItem = new JanelaPesquisar(listaAuxiliar,
                                lc.x,
                                lc.y).getValorRetornado();
                        if (!selectedItem.equals("")) {

                            tfIdPessoa.setText(aux[0]);
                            btBuscar.doClick();
                        } else {
                            tfIdPessoa.requestFocus();
                            tfIdPessoa.selectAll();
                        }
                    }

                    tfIdPessoa.requestFocus();
                    tfIdPessoa.selectAll();
                } else {
                    try {
                        funcionario.setPessoaidPessoa(Integer.valueOf(tfIdPessoa.getText()));
                        funcionario = daoFuncionario.obter(funcionario.getPessoaidPessoa());
                        if (funcionario != null) { //se encontrou na lista
                            tfDataC.setText(cd.getDateParaStringBr(funcionario.getDataContrato()));
                            tfIdDepar.setText(String.valueOf(funcionario.getDepartamentoidDepartamento()));

                            btAdicionar.setVisible(false);
                            btAlterar.setVisible(true);
                            btExcluir.setVisible(true);
                            btSalvar.setVisible(false);
                            btCancelar.setVisible(false);
                            btBuscar.setVisible(true);
                            btListar.setVisible(false);
                         
                            acao = "encontrou";
                        } else {
                            btAdicionar.setVisible(true);
                            btSalvar.setVisible(false);
                            btCancelar.setVisible(false);
                            btBuscar.setVisible(true);
                            btListar.setVisible(true);
                        }
                        tfIdPessoa.setBackground(Color.black);
                        tfIdPessoa.setForeground(Color.green);
                    } catch (Exception x) {
                        tfIdPessoa.setOpaque(true);
                        tfIdPessoa.selectAll();
                        tfIdPessoa.requestFocus();
                        tfIdPessoa.setBackground(Color.red);

                    }
                }
            }
        });
        btAdicionar.setForeground(Color.green);
        btAdicionar.setBackground(Color.black);
        btAdicionar.addActionListener((ActionEvent e) -> {
            tfDataC.requestFocus();
            tfIdPessoa.setEnabled(false);
            tfDataC.setEditable(true);
            tfIdDepar.setEditable(true);
            tfIdDepar.setText("");

            btAdicionar.setVisible(false);
            btSalvar.setVisible(true);
            btCancelar.setVisible(true);
            btBuscar.setVisible(false);
            btListar.setVisible(false);
            acao = "Adicionar";
        });
        btSalvar.setForeground(Color.green);
        btSalvar.setBackground(Color.black);
        btSalvar.addActionListener((ActionEvent e) -> {
            if (acao.equals("Adicionar")) {
                funcionario = new Funcionario();
            }

            funcionario.setPessoaidPessoa(Integer.valueOf(tfIdPessoa.getText()));
            
            String[] aux2 = listaDep[DepartamentoId.getSelectedIndex()].split("-");
            tfIdDepar.setText(aux2[0]);
            
            Departamento d = daoDep.obter(Integer.valueOf(tfIdDepar.getText()));
            
            funcionario.setDepartamentoidDepartamento(d);
            
            funcionario.setDataContrato(tfDataC.getDate());
            
            
            


            if (acao.equals("Adicionar")) {
                daoFuncionario.inserir(funcionario);
            } else {
                daoFuncionario.atualizar(funcionario);
            }
            btSalvar.setVisible(false);
            btCancelar.setVisible(false);
            tfIdPessoa.setEnabled(true);
            tfIdPessoa.setEditable(true);
            tfIdPessoa.requestFocus();

            tfIdPessoa.setText("");
            tfDataC.setText("");
            tfIdDepar.setText("");
            
            btBuscar.setVisible(true);
            btListar.setVisible(true);
            
            tfDataC.setEditable(false);
            tfIdDepar.setEditable(false);
        });
        btAlterar.setForeground(Color.green);
        btAlterar.setBackground(Color.black);
        btAlterar.addActionListener((ActionEvent e) -> {
            btBuscar.setVisible(false);
            btAlterar.setVisible(false);
            tfDataC.requestFocus();
            tfIdPessoa.setEditable(false);
            tfDataC.setEditable(true);
            tfIdDepar.setEditable(true);

            btSalvar.setVisible(true);
            btCancelar.setVisible(true);
            btListar.setVisible(false);
            btExcluir.setVisible(false);
            acao = "alterar";
        });
        btExcluir.setForeground(Color.green);
        btExcluir.setBackground(Color.black);
        btExcluir.addActionListener((ActionEvent e) -> {
            int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {
                daoFuncionario.remover(funcionario);
                System.out.println(funcionario.toString());
            }
            btExcluir.setVisible(false);
            tfIdPessoa.setEnabled(true);
            tfIdPessoa.setEditable(true);
            tfIdPessoa.requestFocus();
            tfIdPessoa.setText("");
            tfDataC.setText("");
            tfIdDepar.setText("");

            btBuscar.setVisible(true);

            tfDataC.setEditable(false);

            btAlterar.setVisible(false);
            btAdicionar.setVisible(false);
            btSalvar.setVisible(false);
            btCancelar.setVisible(false);
            btBuscar.setVisible(true);
            btListar.setVisible(true);
        });
        btListar.setForeground(Color.green);
        btListar.setBackground(Color.black);
        btListar.addActionListener((ActionEvent e) -> {
            List<Funcionario> listaFuncionario = daoFuncionario.listInOrderNome();
            String[] colunas1 = {"Id", "Data do Contrato", "Id do Departamento"};
            Object[][] dados1 = new Object[listaFuncionario.size()][colunas1.length];
            String aux[];
            for (int i = 0; i < listaFuncionario.size(); i++) {
                aux = listaFuncionario.get(i).toString().split(";");
                for (int j = 0; j < colunas1.length; j++) {
                    try {
                        dados1[i][j] = aux[j];
                    } catch (Exception x1) {
                    }
                }
            }
            cardLayout.show(pnSul, "listagem");
            scrollTabela.setPreferredSize(tabela.getPreferredSize());
            pnListagem.add(scrollTabela);
            scrollTabela.setViewportView(tabela);
            model.setDataVector(dados1, colunas1);
            btAlterar.setVisible(false);
            btExcluir.setVisible(false);
            btAdicionar.setVisible(false);
        });
        btCancelar.setForeground(Color.green);
        btCancelar.setBackground(Color.black);
        btCancelar.addActionListener((ActionEvent e) -> {
            btCancelar.setVisible(false);
            tfIdPessoa.setText("");
            tfIdPessoa.requestFocus();
            tfIdPessoa.setEnabled(true);
            tfIdPessoa.setEditable(true);
            tfDataC.setText("");

            tfIdDepar.setText("");

            tfIdDepar.setEditable(false);
            tfDataC.setEditable(false);

            btBuscar.setVisible(true);
            btListar.setVisible(true);
            btSalvar.setVisible(false);
            btCancelar.setVisible(false);
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {

                dispose();
            }
        });

        setModal(true);
        setSize(700, 300);
        setLocationRelativeTo(null);
        setVisible(true);

    }

    public static void main(String[] args) {
        GUIFuncionario guiFuncionario = new GUIFuncionario();
    }

}
