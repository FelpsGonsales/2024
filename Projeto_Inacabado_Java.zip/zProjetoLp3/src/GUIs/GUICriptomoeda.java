package GUIs;

import DAOs.DAOCriptomoeda;
import Entidades.Criptomoeda;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import myUtil.JanelaPesquisar;

public class GUICriptomoeda extends JDialog {

    Container cp;

    JPanel pnNorte = new JPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JLabel lbPK = new JLabel("ID Criptomoeda");
    JTextField tfIdPk = new JTextField(20);

    JLabel lbNome = new JLabel("Nome Criptomoeda");
    JTextField tfCriptomoeda = new JTextField(50);

    JLabel lbSigla = new JLabel("Sigla Criptomoeda");
    JTextField tfSigla = new JTextField(3);

    JLabel lbCriador = new JLabel("Nome Criador Criptomoeda");
    JTextField tfCriador = new JTextField(50);
    
    JLabel lbQuantia = new JLabel("Quantia Disponivel");
    JTextField tfQuantia = new JTextField(50);

    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");

    DAOCriptomoeda daoCriptomoeda = new DAOCriptomoeda();
    Criptomoeda Criptomoeda = new Criptomoeda();
    String acao = "";

    String[] colunas = new String[]{"ID Criptomoeda", "Nome Criptomoeda", "Sigla Criptmoeda", "Nome Criador Criptomoeda", "Quantia Disponível"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(5, 1));

    private CardLayout cardLayout;

    public GUICriptomoeda() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - Criptomoeda");

        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);
        pnNorte.setBackground(Color.black);
        pnCentro.setBackground(Color.black);
        pnSul.setBackground(Color.black);

          
        pnCentro.setBackground(Color.black);
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.gray));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        pnNorte.add(lbPK);
        pnNorte.add(tfIdPk);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);

        pnCentro.setLayout(new GridLayout(5, 2));
        pnCentro.add(lbNome);
        pnCentro.add(tfCriptomoeda);
        pnCentro.add(lbSigla);
        pnCentro.add(tfSigla);
        pnCentro.add(lbCriador);
        pnCentro.add(tfCriador);
        pnCentro.add(lbQuantia);
        pnCentro.add(tfQuantia);

        pnNorte.setBackground(Color.black);
        pnCentro.setBackground(Color.black);
        pnSul.setBackground(Color.black);
        pnSul.setBorder(BorderFactory.createLineBorder(Color.gray));

        tfCriptomoeda.setBackground(Color.black);
        tfCriptomoeda.setForeground(Color.green);
        tfSigla.setForeground(Color.green);
        tfSigla.setBackground(Color.black);
        tfCriador.setForeground(Color.green);
        tfCriador.setBackground(Color.black);
        lbCriador.setBackground(Color.black);
        lbCriador.setForeground(Color.green);
        lbQuantia.setBackground(Color.black);
        lbQuantia.setForeground(Color.green);
        tfQuantia.setForeground(Color.green);
        tfQuantia.setBackground(Color.black);
        lbNome.setForeground(Color.green);
        lbSigla.setForeground(Color.green);
        lbPK.setForeground(Color.green);
        lbPK.setBackground(Color.green);
        tfIdPk.setBackground(Color.black);
        tfIdPk.setForeground(Color.green);

        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnVazio.setBackground(Color.black);
        pnVazio.setForeground(Color.green);
        pnSul.add(pnAvisos, "avisos");
        pnAvisos.setBackground(Color.black);
        pnAvisos.setForeground(Color.green);
        pnSul.add(pnListagem, "listagem");
        pnListagem.setBackground(Color.black);
        pnListagem.setForeground(Color.green);
        tabela.setEnabled(false);
        tabela.setBackground(Color.black);
        tabela.setForeground(Color.green);

        pnAvisos.add(new JLabel("Avisos"));
        btBuscar.setBackground(Color.black);
        btBuscar.setForeground(Color.green);
        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                Criptomoeda = new Criptomoeda();
                tfIdPk.setText(tfIdPk.getText().trim());//caso tenham sido digitados espaços

                if (tfIdPk.getText().equals("")) {
                    List<String> listaAuxiliar = daoCriptomoeda.listInOrderNomeStrings("id");
                    if (listaAuxiliar.size() > 0) {
                        Point lc = btBuscar.getLocationOnScreen();
                        lc.x = lc.x + btBuscar.getWidth();
                        String selectedItem = new JanelaPesquisar(listaAuxiliar,
                                lc.x,
                                lc.y).getValorRetornado();
                        if (!selectedItem.equals("")) {
                            String[] aux = selectedItem.split("-");
                            tfIdPk.setText(aux[0]);
                            btBuscar.doClick();
                        } else {
                            tfIdPk.requestFocus();
                            tfIdPk.selectAll();
                        }
                    }

                    tfIdPk.requestFocus();
                    tfIdPk.selectAll();
                } else {
                    try {
                        Criptomoeda.setIdCriptomoeda(Integer.valueOf(tfIdPk.getText()));
                        Criptomoeda = daoCriptomoeda.obter(Criptomoeda.getIdCriptomoeda());
                        if (Criptomoeda != null) { //se encontrou na lista
                            tfCriptomoeda.setText(String.valueOf(Criptomoeda.getNomeCriptomoeda()));
                            tfSigla.setText(String.valueOf(Criptomoeda.getSiglaCriptomoeda()));
                            tfCriador.setText(String.valueOf(Criptomoeda.getNomeCriador()));

                            btAdicionar.setVisible(false);
                            btAlterar.setVisible(true);
                            btExcluir.setVisible(true);
                            btSalvar.setVisible(false);
                            btCancelar.setVisible(false);
                            btBuscar.setVisible(false);
                            btListar.setVisible(false);
                            acao = "encontrou";
                        } else {
                            btAdicionar.setVisible(true);
                            btSalvar.setVisible(false);
                            btCancelar.setVisible(false);
                            btBuscar.setVisible(true);
                            btListar.setVisible(true);
                        }
                        tfIdPk.setBackground(Color.black);
                        tfIdPk.setForeground(Color.green);

                    } catch (Exception x) {
                        tfIdPk.setOpaque(true);
                        tfIdPk.selectAll();
                        tfIdPk.requestFocus();
                        tfIdPk.setBackground(Color.red);

                    }
                }
            }
        });
        btAdicionar.setForeground(Color.green);
        btAdicionar.setBackground(Color.black);
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfIdPk.setEnabled(false);
                tfCriptomoeda.setEditable(true);
                tfCriptomoeda.requestFocus();
                tfSigla.setEditable(true);
                tfCriador.setEditable(true);
                tfQuantia.setEditable(true);
                
                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                acao = "Adicionar";
            }
        });

        btSalvar.setForeground(Color.green);
        btSalvar.setBackground(Color.black);
        btSalvar.addActionListener((ActionEvent e) -> {
            if (acao.equals("Adicionar")) {
                Criptomoeda = new Criptomoeda();
            }
            if (acao.equals("Adicionar")) {
                Criptomoeda = new Criptomoeda();
            }

            Criptomoeda.setIdCriptomoeda(Integer.valueOf(tfIdPk.getText()));
            Criptomoeda.setNomeCriptomoeda(tfCriptomoeda.getText());
            Criptomoeda.setNomeCriador(tfCriador.getText());
            Criptomoeda.setSiglaCriptomoeda(tfSigla.getText());

            if (acao.equals("Adicionar")) {
                daoCriptomoeda.inserir(Criptomoeda);
            } else {
                daoCriptomoeda.atualizar(Criptomoeda);
            }
            btSalvar.setVisible(false);
            btCancelar.setVisible(false);
            tfIdPk.setEnabled(true);
            tfIdPk.setEditable(true);
            tfIdPk.requestFocus();

            tfIdPk.setText("");
            tfCriador.setText("");
            tfCriptomoeda.setText("");
            tfSigla.setText("");
            tfQuantia.setText("");
            
            btBuscar.setVisible(true);
            btListar.setVisible(true);
            tfCriador.setEditable(false);
            tfQuantia.setEditable(false);
            tfCriptomoeda.setEditable(false);
        });

        btAlterar.setForeground(Color.green);
        btAlterar.setBackground(Color.black);
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                tfIdPk.setEditable(false);
                tfCriptomoeda.setEditable(true);
                tfSigla.setEditable(true);
                tfCriador.setEditable(true);
                tfQuantia.setEditable(true);
                
                tfCriptomoeda.requestFocus();
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                btExcluir.setVisible(false);
                acao = "alterar";

            }
        });
        btExcluir.setForeground(Color.green);
        btExcluir.setBackground(Color.black);
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               try {
                    
               
                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                btExcluir.setVisible(false);
                tfIdPk.setEnabled(true);
                tfIdPk.setEditable(true);
                tfIdPk.requestFocus();
                tfIdPk.setText("");

                tfCriptomoeda.setText("");
                tfSigla.setText("");
                tfCriador.setText("");
                tfQuantia.setText("");
                
                btBuscar.setVisible(true);
                tfCriptomoeda.setEditable(false);
                tfSigla.setEditable(false);
                tfQuantia.setEditable(false);
                btAlterar.setVisible(false);
                if (response == JOptionPane.YES_OPTION) {
                    daoCriptomoeda.remover(Criptomoeda);
                }
                 } catch (Exception eE) {
                    JOptionPane.showMessageDialog(null, "Impossivel excluir, a Criptomoeda está no estoque! Exclua para prosseguir!");
                }
            }
        });
        btListar.setForeground(Color.green);
        btListar.setBackground(Color.black);
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Criptomoeda> listaCriptomoeda = daoCriptomoeda.list();
                String[] colunas = {"Id", "Nome", "Sigla", "Criador","Quantia Disponivel"};
                Object[][] dados = new Object[listaCriptomoeda.size()][colunas.length];
                String aux[];

                for (int i = 0; i < listaCriptomoeda.size(); i++) {
                    aux = listaCriptomoeda.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        try {
                            dados[i][j] = aux[j];
                        } catch (Exception x) {
                            
                        }
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);

                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);

            }
        });
        btCancelar.setForeground(Color.green);
        btCancelar.setBackground(Color.black);
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btCancelar.setVisible(false);
                tfIdPk.setText("");
                tfIdPk.requestFocus();
                tfIdPk.setEnabled(true);
                tfIdPk.setEditable(true);
                tfCriptomoeda.setText("");
                tfCriptomoeda.setEditable(false);
                tfSigla.setText("");
                tfSigla.setEditable(false);
                tfCriador.setText("");
                tfCriador.setEditable(false);
                tfQuantia.setText("");
                tfQuantia.setEditable(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);

            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {

                dispose();
            }
        });

        setModal(true);
        setSize(700, 500);
        setLocationRelativeTo(null);
        setVisible(true);

    }

}
