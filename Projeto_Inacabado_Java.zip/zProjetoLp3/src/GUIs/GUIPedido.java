package GUIs;

import DAOs.DAOCliente;
import DAOs.DAOCriptomoeda;
import DAOs.DAOPedido;
import Entidades.Cliente;
import Entidades.PedidoHasCriptomoeda;
import Entidades.Pedido;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import myUtil.DateTextField;
import myUtil.JanelaPesquisar;

public class GUIPedido extends JDialog {

    Container cp;

    JPanel pnNorte = new JPanel();
    JPanel pnCentro = new JPanel();
    JPanel pnSul = new JPanel();
    JLabel lbPK = new JLabel("ID do Pedido");
    JTextField tfIdPk = new JTextField(20);
    JComboBox ClienteId = new JComboBox();
    JComboBox CriptoId = new JComboBox();
    

    JLabel lbDataN = new JLabel("Data do Pedido");
    DateTextField tfDataN = new DateTextField();

    JLabel lbIdCliente = new JLabel("Id e Nome do Cliente");
    JTextField tfidCliente = new JTextField(2);
    
  
    
    JLabel lbCripto = new JLabel("Id e Nome da Criptomoeda");
    JTextField tfCripto = new JTextField(2);
    
    JLabel lbQuantia = new JLabel("Quantidade");
    JTextField tfQuantia = new JTextField(10);
    
    JLabel lbValor = new JLabel("Valor pago");
    JTextField tfValor = new JTextField(10);
  
    
    
    JButton btBuscar = new JButton("Buscar");
    JButton btAdicionar = new JButton("Adicionar");
    JButton btSalvar = new JButton("Salvar");
    JButton btAlterar = new JButton("Alterar");
    JButton btExcluir = new JButton("Excluir");
    JButton btListar = new JButton("Listar");
    JButton btCancelar = new JButton("Cancelar");

    DAOPedido daoPedido = new DAOPedido();
    Pedido Pedido = new Pedido();
    String acao = "";

    String[] colunas = new String[]{"ID Pedido", "id do Cliente", "Data Pedido", "Quantia" , "Valor Pago"};
    String[][] dados = new String[0][colunas.length];

    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    private JScrollPane scrollTabela = new JScrollPane();

    private JPanel pn1x1 = new JPanel(new GridLayout (1, 1));
    private JPanel pnAvisos = new JPanel(new GridLayout(1, 1));
    private JPanel pnListagem = new JPanel(new GridLayout(1, 1));
    private JPanel pnVazio = new JPanel(new GridLayout(6, 1));

    private CardLayout cardLayout;

    public GUIPedido() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("CRUD - Pedido");

        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);
        cp.add(pnSul, BorderLayout.SOUTH);
        pnNorte.setBackground(Color.black);
        pnCentro.setBackground(Color.black);
        pnSul.setBackground(Color.black);

          
        pnCentro.setBackground(Color.black);
        pnCentro.setBorder(BorderFactory.createLineBorder(Color.gray));

        pnNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
        pnNorte.add(lbPK);
        pnNorte.add(tfIdPk);
        pnNorte.add(lbDataN);
        pnNorte.add(tfDataN);
        pnNorte.add(btBuscar);
        pnNorte.add(btAdicionar);
        pnNorte.add(btAlterar);
        pnNorte.add(btExcluir);
        pnNorte.add(btListar);
        pnNorte.add(btSalvar);
        pnNorte.add(btCancelar);
        
        pnCentro.add(lbIdCliente);
        pnCentro.add(ClienteId);


        pnCentro.add(lbQuantia);
        pnCentro.add(tfQuantia);
        pnCentro.add(lbValor);
        pnCentro.add(tfValor);

        btSalvar.setVisible(false);
        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btCancelar.setVisible(false);

        pnCentro.setLayout(new GridLayout(3, 2));
 

        pnNorte.setBackground(Color.black);
        pnCentro.setBackground(Color.black);
        pnSul.setBackground(Color.black);
        pnSul.setBorder(BorderFactory.createLineBorder(Color.gray));

        DAOCliente daoCliente = new DAOCliente();
        String[]  listaCliente = daoCliente.listInOrderNomeStringsArray();
        for (String s : listaCliente) {
            ClienteId.addItem(s);
        }
        
         DAOCriptomoeda daoCriptomoeda = new DAOCriptomoeda();
        String[]  listaCriptomoeda = daoCriptomoeda.listInOrderNomeStringsArray();
        for (String s : listaCliente) {
            CriptoId.addItem(s);
        }
        
        
        tfQuantia.setBackground(Color.black);
        tfQuantia.setForeground(Color.green);
        tfValor.setBackground(Color.black);
        tfValor.setForeground(Color.green);
       
        lbDataN.setForeground(Color.green);
        lbQuantia.setForeground(Color.green);
        lbValor.setForeground(Color.green);
        
        
        
        tfDataN.setBackground(Color.black);
        tfDataN.setForeground(Color.green);
        ClienteId.setForeground(Color.green);
        ClienteId.setBackground(Color.black);
        CriptoId.setForeground(Color.green);
        CriptoId.setBackground(Color.black);
        
        lbPK.setForeground(Color.green);
        lbPK.setBackground(Color.green);
        tfIdPk.setBackground(Color.black);
        tfIdPk.setForeground(Color.green);
     

        lbIdCliente.setForeground(Color.green);
        lbIdCliente.setBackground(Color.black);
        tfidCliente.setForeground(Color.green);
        tfidCliente.setBackground(Color.black);
        lbCripto.setForeground(Color.green);
        lbCripto.setBackground(Color.black);
        tfCripto.setForeground(Color.green);
        tfCripto.setBackground(Color.black);
        
        cardLayout = new CardLayout();
        pnSul.setLayout(cardLayout);

        for (int i = 0; i < 5; i++) {
            pnVazio.add(new JLabel(" "));
        }
        pnSul.add(pnVazio, "vazio");
        pnNorte.add(pn1x1, " ");
        pnVazio.setBackground(Color.black);
        pnVazio.setForeground(Color.green);
        pnSul.add(pnAvisos, "avisos");
        pnAvisos.setBackground(Color.black);
        pnAvisos.setForeground(Color.green);
        pnSul.add(pnListagem, "listagem");
        pnListagem.setBackground(Color.black);
        pnListagem.setForeground(Color.green);
        tabela.setEnabled(false);
        tabela.setBackground(Color.black);
        tabela.setForeground(Color.green);

        pnAvisos.add(new JLabel("Avisos"));
        btBuscar.setBackground(Color.black);
        btBuscar.setForeground(Color.green);
        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                Pedido = new Pedido();
                tfIdPk.setText(tfIdPk.getText().trim());//caso tenham sido digitados espaços

                    String[] aux2 = listaCliente[ClienteId.getSelectedIndex()].split("-");
                    tfidCliente.setText(aux2[0]);
                
                    
                if (tfIdPk.getText().equals("")) {
                    List<String> listaAuxiliar = daoPedido.listInOrderNomeStrings("id");
                    if (listaAuxiliar.size() > 0) {
                        Point lc = btBuscar.getLocationOnScreen();
                        lc.x = lc.x + btBuscar.getWidth();
                        String selectedItem = new JanelaPesquisar(listaAuxiliar,
                                lc.x,
                                lc.y).getValorRetornado();
                        if (!selectedItem.equals("")) {
                            String[] aux = selectedItem.split("-");
                            tfIdPk.setText(aux[0]);
                            btBuscar.doClick();
                        } else {
                            tfIdPk.requestFocus();
                            tfIdPk.selectAll();
                        }
                    }

                    tfIdPk.requestFocus();
                    tfIdPk.selectAll();
                } else {
                    try {
                        Pedido.setIdPedido(Integer.valueOf(tfIdPk.getText()));
                        Pedido = daoPedido.obter(Pedido.getIdPedido());
                        if (Pedido != null) { //se encontrou na lista
                            tfidCliente.setText(String.valueOf(Pedido.getClienteidCliente()));
                            tfDataN.setText(String.valueOf(Pedido.getDataContrato()));
                            

                            btAdicionar.setVisible(false);
                            btAlterar.setVisible(true);
                            btExcluir.setVisible(true);
                            btSalvar.setVisible(false);
                            btCancelar.setVisible(false);
                            btBuscar.setVisible(false);
                            btListar.setVisible(false);
                            acao = "encontrou";
                        } else {
                            btAdicionar.setVisible(true);
                            btSalvar.setVisible(false);
                            btCancelar.setVisible(false);
                            btBuscar.setVisible(true);
                            btListar.setVisible(true);
                        }
                        tfIdPk.setBackground(Color.black);
                        tfIdPk.setForeground(Color.green);

                    } catch (Exception x) {
                        tfIdPk.setOpaque(true);
                        tfIdPk.selectAll();
                        tfIdPk.requestFocus();
                        tfIdPk.setBackground(Color.red);

                    }
                }
            }
        });
        btAdicionar.setForeground(Color.green);
        btAdicionar.setBackground(Color.black);
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfIdPk.setEnabled(false);
                tfDataN.setEditable(true);
                tfQuantia.setEditable(true);
                tfValor.setEditable(true);
               
                tfDataN.requestFocus();
      
                
                btAdicionar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                acao = "Adicionar";
            }
        });

        btSalvar.setForeground(Color.green);
        btSalvar.setBackground(Color.black);
        btSalvar.addActionListener((ActionEvent e) -> {
            if (acao.equals("Adicionar")) {
                Pedido = new Pedido();
            }
            Pedido.setIdPedido(Integer.valueOf(tfIdPk.getText()));
            Pedido.setDataContrato(tfDataN.getDate());
            
            String[] aux2 = listaCliente[ClienteId.getSelectedIndex()].split("-");
            tfidCliente.setText(aux2[0]);
            
            Cliente c = daoCliente.obter(Integer.valueOf(tfidCliente.getText()));
            
            Pedido.setClienteidCliente(c.getPessoaidPessoa());
       
           
   

            if (acao.equals("Adicionar")) {
                daoPedido.inserir(Pedido);
            } else {
                daoPedido.atualizar(Pedido);
            }
            btSalvar.setVisible(false);
            btCancelar.setVisible(false);
            tfIdPk.setEnabled(true);
            tfIdPk.setEditable(true);
            tfIdPk.requestFocus();

            tfIdPk.setText("");
            tfDataN.setText("");

            
            btBuscar.setVisible(true);
            btListar.setVisible(true);
            tfDataN.setEditable(false);
        });

        btAlterar.setForeground(Color.green);
        btAlterar.setBackground(Color.black);
        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btBuscar.setVisible(false);
                btAlterar.setVisible(false);
                tfIdPk.setEditable(false);
                tfDataN.setEditable(true);

                tfDataN.requestFocus();
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btListar.setVisible(false);
                btExcluir.setVisible(false);
                acao = "alterar";

            }
        });
        btExcluir.setForeground(Color.green);
        btExcluir.setBackground(Color.black);
        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               try {
                    
               
                int response = JOptionPane.showConfirmDialog(cp, "Confirme a exclusão?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                btExcluir.setVisible(false);
                tfIdPk.setEnabled(true);
                tfIdPk.setEditable(true);
                tfIdPk.requestFocus();
                tfIdPk.setText("");

                tfDataN.setText("");

                
                btBuscar.setVisible(true);
                tfDataN.setEditable(false);
                btAlterar.setVisible(false);
                if (response == JOptionPane.YES_OPTION) {
                    daoPedido.remover(Pedido);
                }
                 } catch (Exception eE) {
                    JOptionPane.showMessageDialog(null, "Impossivel excluir, a Pedido está no estoque! Exclua para prosseguir!");
                }
            }
        });
        btListar.setForeground(Color.green);
        btListar.setBackground(Color.black);
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Pedido> listaPedido = daoPedido.list();
                String[] colunas = {"Id", "Nome", "Sigla", "Criador","Quantia Disponivel"};
                Object[][] dados = new Object[listaPedido.size()][colunas.length];
                String aux[];

                for (int i = 0; i < listaPedido.size(); i++) {
                    aux = listaPedido.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        try {
                            dados[i][j] = aux[j];
                        } catch (Exception x) {
                            
                        }
                    }
                }
                cardLayout.show(pnSul, "listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                pnListagem.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);

                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);

            }
        });
        btCancelar.setForeground(Color.green);
        btCancelar.setBackground(Color.black);
        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btCancelar.setVisible(false);
                tfIdPk.setText("");
                tfIdPk.requestFocus();
                tfIdPk.setEnabled(true);
                tfIdPk.setEditable(true);
                tfDataN.setText("");
                tfDataN.setEditable(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);

            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {

                dispose();
            }
        });

        setModal(true);
        setSize(900, 800);
        setLocationRelativeTo(null);
        setVisible(true);

    }

}
