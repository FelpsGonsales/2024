package GUIs;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;




public class MenuPrincipal extends JFrame {
    private Container cp;
    private JPanel norte = new JPanel();
    private JButton btFuncionario = new JButton("Funcionarios Only");
    private JButton btPessoa = new JButton("Clientes/ Informações");
    private  JLabel lebel = new JLabel("Bem vindo ao site!");
    private  JLabel lbFoto = new JLabel();

  
    
    public MenuPrincipal() {
        
        lbFoto = new javax.swing.JLabel();
        lbFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Fotos/tpose.png"))); // NOI18N
       

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(lbFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(lbFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
   
        
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        norte.setBackground(Color.black);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("CriptoLands");
       
        cp.setLayout(new GridLayout(1,2));
        
        cp.add(norte, BorderLayout.NORTH);
       
        
       
        norte.add(btFuncionario);
        norte.add(lebel);
        norte.add(btPessoa);
       norte.add(lbFoto);
       
        
        btFuncionario.setForeground(Color.black);
        btFuncionario.setBackground(Color.white);
        btPessoa.setForeground(Color.black);
        btPessoa.setBackground(Color.white);      
        lebel.setForeground(Color.green);
       
        
        btFuncionario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              MenuFuncionario guiFuncionario= new MenuFuncionario();
            }
        });
        btPessoa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MenuPessoa guiPessoa= new MenuPessoa();
            }
        });
        
        setSize(800,550);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    
    
}
