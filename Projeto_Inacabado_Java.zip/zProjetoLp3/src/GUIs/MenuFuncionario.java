package GUIs;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;




public class MenuFuncionario extends JFrame {
    private Container cp;
    private JPanel norte = new JPanel();
    private JPanel sul= new JPanel();
    private JButton btCriptomoeda = new JButton("Cadastrar Criptomoeda");
    private  JLabel lbFoto = new JLabel();
    private JButton btDepartamento = new JButton("Cadastrar Departamentos");
    private JButton btFuncionario = new JButton("Cadastrar Funcionarios");
  
    
    public MenuFuncionario() {
        
        lbFoto = new javax.swing.JLabel();
        lbFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Fotos/tpose.png"))); // NOI18N
       

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(lbFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(lbFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
   
        
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        norte.setBackground(Color.black);
        sul.setBackground(Color.black);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Cadastro das Criptmoeda mermão");
       
        cp.setLayout(new GridLayout(1,2));
        
        cp.add(norte, BorderLayout.NORTH);
        cp.add(sul, BorderLayout.SOUTH);
        
       
       norte.add(btCriptomoeda);
       norte.add(btDepartamento);
       norte.add(btFuncionario);
       sul.add(lbFoto);
       
        
        btCriptomoeda.setForeground(Color.black);
        btCriptomoeda.setBackground(Color.white);
        btDepartamento.setForeground(Color.black);
        btDepartamento.setBackground(Color.white);
        btFuncionario.setForeground(Color.black);
        btFuncionario.setBackground(Color.white);
        
        
        btCriptomoeda.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              GUICriptomoeda guiCriptomoeda= new GUICriptomoeda();
            }
        });
        
        btDepartamento.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              GUIDepartamento guiDepartamento= new GUIDepartamento();
            }
        });
        btFuncionario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              GUIFuncionario guiFuncionario= new GUIFuncionario();
            }
        });
        
        setSize(800,550);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    
    
}
