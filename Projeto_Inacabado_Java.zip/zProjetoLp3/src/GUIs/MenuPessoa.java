package GUIs;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;




public class MenuPessoa extends JFrame {
    private Container cp;
    private JPanel norte = new JPanel();
  
    private JButton btPessoa = new JButton("Clientes / Informações");
    private JButton btPedido = new JButton("Pedir");
    
    private  JLabel lebel = new JLabel("Cadastro Geral");
    private  JLabel lbFoto = new JLabel();

  
    
    public MenuPessoa() {
        
        lbFoto = new javax.swing.JLabel();
        lbFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Fotos/Cadastro.png"))); 
       

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(lbFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(lbFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
   
        
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        norte.setBackground(Color.black);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Cadastro Pessoas");
       
        cp.setLayout(new GridLayout(1,3));
        
        cp.add(norte, BorderLayout.NORTH);
       
        
       
        norte.add(lebel);
        norte.add(btPessoa);
       norte.add(lbFoto);
       norte.add(btPedido);
       
        
        btPessoa.setForeground(Color.black);
        btPessoa.setBackground(Color.white);      
        lebel.setForeground(Color.green);
       
  
        btPessoa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            GUIPessoa guiPessoa = new GUIPessoa();
            }
        });
        
        btPedido.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIPedido guiPedido = new GUIPedido();
            }
        });
        
        setSize(800,550);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    
    
}
