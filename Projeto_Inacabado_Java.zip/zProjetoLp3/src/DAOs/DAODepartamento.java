package DAOs;

import Entidades.Departamento;
import java.util.ArrayList;
import java.util.List;

public class DAODepartamento extends DAOGenerico<Departamento> {

private final List<Departamento> lista = new ArrayList<>();    public DAODepartamento(){
        super(Departamento.class);
    }

    public int autoIdDepartamento() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idDepartamento) FROM Departamento e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Departamento> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Departamento e WHERE e.idDepartamento LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Departamento> listById(int id) {
        return em.createQuery("SELECT e FROM Departamento + e WHERE e.nomeDep= :id").setParameter("id", id).getResultList();
    }

    public List<Departamento> listInOrderNome() {
        return em.createQuery("SELECT e FROM Departamento e ORDER BY e.nomeDep").getResultList();
    }

    public List<Departamento> listInOrderId() {
        return em.createQuery("SELECT e FROM Departamento e ORDER BY e.idDepartamento").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Departamento> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdDepartamento() + "-" + lf.get(i).getNomeDep());
        }
        return ls;
    }

 public String[] listInOrderNomeStringsArray() {
        List<Departamento> lf = listInOrderNome();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i]=(lf.get(i).getIdDepartamento()+ "-" + lf.get(i).getNomeDep());
        }
        return ls;
    }
 
public static void main(String[] args) {
        DAODepartamento daoDepartamento = new DAODepartamento();
        List<Departamento> listaDepartamento = daoDepartamento.list();
        for (Departamento departamento : listaDepartamento) {
            System.out.println(departamento.getIdDepartamento()+"-"+departamento.getNomeDep());
        }
    }}