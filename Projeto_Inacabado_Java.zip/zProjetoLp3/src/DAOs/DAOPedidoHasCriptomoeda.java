package DAOs;

import Entidades.Cliente;
import java.util.ArrayList;
import java.util.List;

public class DAOPedidoHasCriptomoeda extends DAOGenerico<Cliente> {

private final List<Cliente> lista = new ArrayList<>();    public DAOPedidoHasCriptomoeda(){
        super(Cliente.class);
    }

    public int autoPessoaidPessoa() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.pessoaidPessoa) FROM Cliente e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Cliente> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Cliente e WHERE e.pessoaidPessoa LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Cliente> listById(int id) {
        return em.createQuery("SELECT e FROM Cliente + e WHERE e.cidadeCliente= :id").setParameter("id", id).getResultList();
    }

    public List<Cliente> listInOrderNome() {
        return em.createQuery("SELECT e FROM Cliente e ORDER BY e.cidadeCliente").getResultList();
    }

    public List<Cliente> listInOrderId() {
        return em.createQuery("SELECT e FROM Cliente e ORDER BY e.pessoaidPessoa").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Cliente> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getPessoaidPessoa() + "-" + lf.get(i).getCidadeCliente());
        }
        return ls;
    }
    
 public String[] listInOrderNomeStringsArray() {
        List<Cliente> lf = listInOrderNome();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i]=(lf.get(i).getPessoaidPessoa()+ "-" + lf.get(i).getPessoa().getNomePessoa());
        }
        return ls;
    }
 

public static void main(String[] args) {
        DAOPedidoHasCriptomoeda daoCliente = new DAOPedidoHasCriptomoeda();
        List<Cliente> listaCliente = daoCliente.list();
        for (Cliente cliente : listaCliente) {
            System.out.println(cliente.getPessoaidPessoa()+"-"+cliente.getCidadeCliente());
        }
    }}