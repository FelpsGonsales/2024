package DAOs;

import Entidades.Criptomoeda;
import java.util.ArrayList;
import java.util.List;

public class DAOCriptomoeda extends DAOGenerico<Criptomoeda> {

    private List<Criptomoeda> lista = new ArrayList<>();

    public DAOCriptomoeda() {
        super(Criptomoeda.class);
    }

    public int autoIdCriptomoeda() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.cpf) FROM Criptomoeda e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

      public List<Criptomoeda> listByNomeCriador(String nome_criador) {
        return em.createQuery("SELECT e FROM Criptomoeda e WHERE e.idCriptomoeda) LIKE :nome_criador").setParameter("nome_criador", "%" + nome_criador + "%").getResultList();
    }
      public List<Criptomoeda> listBySiglaCriptomoeda(String sigla_criptomoeda) {
        return em.createQuery("SELECT e FROM Criptomoeda e WHERE e.idCriptomoeda) LIKE :sigla_criptomoeda").setParameter("sigla_criptomoeda", "%" + sigla_criptomoeda + "%").getResultList();
    }
    public List<Criptomoeda> listByNomeCriptomoeda(String nome_criptomoeda) {
        return em.createQuery("SELECT e FROM Criptomoeda e WHERE e.idCriptomoeda) LIKE :nome_criptomoeda").setParameter("nome_criptomoeda", "%" + nome_criptomoeda + "%").getResultList();
    }

    public List<Criptomoeda> listById(int idCriptomoeda) {
        return em.createQuery("SELECT e FROM Criptomoeda + e WHERE e.idCriptomoeda= :idCriptomoeda").setParameter("idCriptomoeda", idCriptomoeda).getResultList();
    }

    public List<Criptomoeda> listInOrderNomeCriador() {
        return em.createQuery("SELECT e FROM Criptomoeda e ORDER BY e.nomeCriador").getResultList();
    }
    public List<Criptomoeda> listInOrderNomeCriptomoeda() {
        return em.createQuery("SELECT e FROM Criptomoeda e ORDER BY e.nomeCriptomoeda").getResultList();
    }
    public List<Criptomoeda> listInOrderSiglaCriptomoeda() {
        return em.createQuery("SELECT e FROM Criptomoeda e ORDER BY e.siglaCriptomoeda").getResultList();
    }

    public List<Criptomoeda> listInOrderId() {
        return em.createQuery("SELECT e FROM Criptomoeda e ORDER BY e.idCriptomoeda").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Criptomoeda> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
           lf = listInOrderNomeCriptomoeda();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdCriptomoeda()+ "-" + lf.get(i).getNomeCriptomoeda()+ "-" + lf.get(i).getNomeCriador()+ "-" + lf.get(i).getSiglaCriptomoeda());
        }
        return ls;
    }
    
     public String[] listInOrderNomeStringsArray() {
        List<Criptomoeda> lf = listInOrderNomeCriador();
        String[] ls = new String[lf.size()];
        for (int i = 0; i < lf.size(); i++) {
            ls[i]=(lf.get(i).getIdCriptomoeda()+ "-" + lf.get(i).getNomeCriador());
        }
        return ls;
    }
 

    public static void main(String[] args) {
        DAOCriptomoeda daoCriptomoeda = new DAOCriptomoeda();
        List<Criptomoeda> listaCriptomoeda = daoCriptomoeda.list();
        for (Criptomoeda criptomoeda : listaCriptomoeda) {
            System.out.println(criptomoeda.getIdCriptomoeda()+ "-" + criptomoeda.getNomeCriptomoeda()+ "-" + criptomoeda.getNomeCriador()+ "-" +criptomoeda.getSiglaCriptomoeda());
        }
    }
}
  
