package Main;

import GUIs.MenuPrincipal;

/**
 *
 * @author Gonsales
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MenuPrincipal menuPrincipal = new MenuPrincipal();
    }
    
}
